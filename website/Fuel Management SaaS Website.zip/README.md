
  # Fuel Management SaaS Website

  This is a code bundle for Fuel Management SaaS Website. The original project is available at https://www.figma.com/design/iVP4wa6QE7P4ugM0HJJMZd/Fuel-Management-SaaS-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  